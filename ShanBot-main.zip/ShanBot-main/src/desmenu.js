const desmenu = (prefix, pushname) => {
    return `
*Comandos De Descargas ✅*
 
- ${prefix}play
  Coloca el nombre de la cancion. O el link del video YT
- ${prefix}ytmp3
  Coloca el link del video YT
- ${prefix}ytmp4
  Coloca el link del video YT
    
_*play tiene un limite de 2000 canciones si llega a su limite se restablecera dentro de 24 horas_
     
by shanduy`

}

exports.desmenu = desmenu
