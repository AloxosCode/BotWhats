const version = (prefix, pushname) => {
    return `
*ShanBot 🤖*

*Actualizado:* 4 de junio de 2021
*Versión actual:* 2.1
*Ofrecida por:* shanduy

Para conocer la ultima versión de ShanBot entra al siguiente blog

https://github.com/shanduy/ShanBot

by shanduy
`

}

exports.version = version
